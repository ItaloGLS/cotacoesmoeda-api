package com.example.cotacaomoedas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var editMoeda: EditText
    private lateinit var btnBuscar: Button
    private lateinit var textResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editMoeda = findViewById(R.id.editMoeda)
        btnBuscar = findViewById(R.id.btnBuscar)
        textResultado = findViewById(R.id.textResultado)

        // Configuração do Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl("https://economia.awesomeapi.com.br/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val api = retrofit.create(MoedaApi::class.java)

        // Clique do botão
        btnBuscar.setOnClickListener {
            val sigla = editMoeda.text.toString().trim().uppercase()

            if (sigla.isEmpty()) {
                textResultado.text = "Digite a sigla da moeda!"
                return@setOnClickListener
            }

            val call = api.getCotacao(sigla)

            call.enqueue(object : Callback<Map<String, MoedaResponse>> {
                override fun onResponse(
                    call: Call<Map<String, MoedaResponse>>,
                    response: Response<Map<String, MoedaResponse>>
                ) {
                    if (response.isSuccessful) {
                        val body = response.body()
                        val key = "${sigla}BRL"

                        val moeda = body?.get(key)
                        if (moeda != null) {
                            val texto = """
                                Moeda: ${moeda.name}
                                Alta: R$ ${moeda.high}
                                Baixa: R$ ${moeda.low}
                                Valor atual: R$ ${moeda.bid}
                                Atualizado em: ${moeda.create_date}
                            """.trimIndent()
                            textResultado.text = texto
                        } else {
                            textResultado.text = "Moeda não encontrada."
                        }
                    } else {
                        textResultado.text = "Erro na resposta da API."
                    }
                }

                override fun onFailure(call: Call<Map<String, MoedaResponse>>, t: Throwable) {
                    textResultado.text = "Erro: ${t.message}"
                }
            })
        }
    }
}
