package com.example.cotacaomoedas

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface MoedaApi {
    @GET("json/last/{moeda}-BRL")
    fun getCotacao(@Path("moeda") moeda: String): Call<Map<String, MoedaResponse>>
}
